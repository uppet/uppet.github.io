"""Export a verified book into one directory for an existing Jekyll Pages site.

Run from the project root: python book/export_pages.py .publish/pages/blender_renderer_book
The destination must be absent or empty. This command does not commit or publish.
"""
import argparse
import hashlib
import json
from pathlib import Path

BOOK = Path(__file__).resolve().parent
ROOT = BOOK.parent


def sha256(raw):
    return hashlib.sha256(raw).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('destination', type=Path)
    destination = parser.parse_args().destination.resolve()
    if destination.exists() and (not destination.is_dir() or any(destination.iterdir())):
        raise RuntimeError('Use an absent or empty export directory; existing content is preserved.')

    browser = json.loads((BOOK / 'verification/browser-report.json').read_text(encoding='utf-8'))
    if not browser.get('passed') or browser.get('browserExitCode') != 0:
        raise RuntimeError('Run the local browser verification before exporting.')
    for name, expected in browser['verifiedFiles'].items():
        if sha256((BOOK / name).read_bytes()) != expected:
            raise RuntimeError(f'Book changed after browser verification: {name}')
    portable = json.loads((BOOK / 'portable-report.json').read_text(encoding='utf-8'))
    portable_bytes = (ROOT / 'astra-renderer-book.zip').read_bytes()
    if sha256(portable_bytes) != portable['sha256']:
        raise RuntimeError('Portable ZIP does not match its verification report.')

    script = (BOOK / 'data.js').read_text(encoding='utf-8')
    prefix = 'window.BOOK = '
    if not script.startswith(prefix) or not script.rstrip().endswith(';'):
        raise RuntimeError('Unexpected book data format.')
    data = json.loads(script[len(prefix):].rstrip()[:-1])
    manifest = json.loads((BOOK / 'manifest.json').read_text(encoding='utf-8'))
    # Jekyll skips dot/underscore names and may transform Markdown. Only the
    # hosted download URLs change; displayed source names, bytes and ZIPs do not.
    aliases = {
        'project/.gitignore': 'project/gitignore.txt',
        'project/README.md': 'project/README.md.txt',
        'project/astra_press/__init__.py': 'project/astra_press/init.py.txt',
    }
    payload = {name: (BOOK / name).read_bytes()
               for name in ('index.html', 'style.css', 'reader.js', 'labs.js',
                            'astra-press-project.zip')}
    for item in data['files'].values():
        raw = (BOOK / item['href']).read_bytes()
        if len(raw) != item['size'] or sha256(raw) != item['sha256']:
            raise RuntimeError(f'Snapshot changed: {item["path"]}')
        item['href'] = aliases.get(item['href'], item['href'])
        payload[item['href']] = raw
    for item in manifest['files']:
        item['href'] = aliases.get(item['href'], item['href'])
    for chapter in data['chapters']:
        for old, new in aliases.items():
            chapter['html'] = chapter['html'].replace('"' + old + '"', '"' + new + '"')
    payload['data.js'] = ('window.BOOK = ' + json.dumps(
        data, ensure_ascii=False, separators=(',', ':'), allow_nan=False) + ';\n').encode('utf-8')
    payload['manifest.json'] = (json.dumps(manifest, ensure_ascii=False, indent=2) + '\n').encode('utf-8')

    index = payload['index.html'].decode('utf-8')
    footer = '<span>本地阅读 · 无外部依赖 · 可携带源码与成果</span>'
    if index.count(footer) != 1:
        raise RuntimeError('Reader footer changed; update the offline download link.')
    index = index.replace(footer, '<a href="astra-renderer-book.zip" download>下载离线整本 ZIP ↓</a>')
    index = index.replace('章节 Markdown 位于 chapters 目录。', '章节 Markdown 随离线整本 ZIP 提供。')
    payload['index.html'] = index.encode('utf-8')
    payload['astra-renderer-book.zip'] = portable_bytes
    release = {
        'title': data['title'], 'directory': 'blender_renderer_book',
        'chapters': len(data['chapters']), 'snapshotFiles': len(data['files']),
        'downloadAliases': aliases,
        'files': [{'path': name, 'bytes': len(raw), 'sha256': sha256(raw)}
                  for name, raw in sorted(payload.items())],
    }
    payload['publication-manifest.json'] = (json.dumps(
        release, ensure_ascii=False, indent=2) + '\n').encode('utf-8')
    # Git control file, intentionally excluded from the HTTP asset manifest.
    payload['.gitattributes'] = b'* -text\n*.json whitespace=cr-at-eol\n'
    for name, raw in payload.items():
        target = destination / name
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(raw)
        if target.read_bytes() != raw:
            raise RuntimeError(f'Export verification failed: {name}')
    print('BOOK_PAGES_EXPORT_OK ' + json.dumps({
        'destination': str(destination), 'files': len(payload),
        'bytes': sum(map(len, payload.values())), 'chapters': len(data['chapters']),
    }, ensure_ascii=False), flush=True)


if __name__ == '__main__':
    main()
