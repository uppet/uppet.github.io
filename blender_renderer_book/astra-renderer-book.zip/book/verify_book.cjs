/* Native Windows browser acceptance checks, with no npm dependencies.
   Run from project root: node book/verify_book.cjs
   An isolated headless Edge/Chrome profile is removed after the run. */
'use strict';
const fs=require('node:fs');
const path=require('node:path');
const vm=require('node:vm');
const crypto=require('node:crypto');
const {spawn}=require('node:child_process');
const {pathToFileURL}=require('node:url');
const BOOK=__dirname, ROOT=path.dirname(BOOK);
const ONLINE=Boolean(process.env.ASTRA_BOOK_URL);
const ENTRY=process.env.ASTRA_BOOK_URL||pathToFileURL(path.join(ROOT,'打开这本书.html')).href;
const CHECKS=ONLINE?path.join(ROOT,'.publish','online-checks'):path.join(BOOK,'verification');
fs.mkdirSync(CHECKS,{recursive:true});
let assertions=0;
function check(condition,message){assertions++;if(!condition)throw new Error(message);}
const delay=ms=>new Promise(resolve=>setTimeout(resolve,ms));
async function waitUntil(fn,message,timeout=12000){
  const start=Date.now();let latest;
  while(Date.now()-start<timeout){try{latest=await fn();if(latest)return latest;}catch(error){latest=error.message;}await delay(60);}
  throw new Error(message+': '+String(latest));
}
const context={window:{},AbortController};
for(const file of ['data.js','labs.js','reader.js'])new vm.Script(fs.readFileSync(path.join(BOOK,file),'utf8'),{filename:file});
vm.runInNewContext(fs.readFileSync(path.join(BOOK,'data.js'),'utf8'),context);
vm.runInNewContext(fs.readFileSync(path.join(BOOK,'labs.js'),'utf8'),context);
const book=context.window.BOOK;
const math=context.window.BookLabs.math;
check(book.chapters.length===27,'Expected all 27 chapters');
check(book.han>28000,'Expected a substantial complete manuscript');
const chapters=new Map(book.chapters.map(c=>[c.id,c]));
let localLinks=0, sourceExcerpts=0;
for(const chapter of book.chapters){
  check(!/:::lab |:::code |:::exercise /.test(chapter.html),'Unexpanded directive in '+chapter.id);
  check(chapter.toc.length>=3,'Insufficient chapter structure: '+chapter.id);
  const ids=[...chapter.html.matchAll(/\bid="([^"]+)"/g)].map(m=>m[1]);
  check(new Set(ids).size===ids.length,'Duplicate anchors: '+chapter.id);
  sourceExcerpts+=(chapter.html.match(/查看完整源码/g)||[]).length;
  for(const match of chapter.html.matchAll(/\b(?:href|src)="([^"]+)"/g)){
    const href=match[1];if(href.startsWith('https://'))continue;
    localLinks++;
    if(href.startsWith('#source/')){
      const spec=href.slice(8),m=spec.match(/^(.*?)(?::(\d+))?$/),file=book.files[m[1]];
      check(file?.kind==='text','Missing source: '+href);
      if(m[2])check(Number(m[2])<=file.text.split('\n').length,'Invalid source line '+href);
    }else if(href.startsWith('#ch/')){
      const [,id,anchor]=href.slice(1).split('/');
      check(chapters.has(id),'Missing chapter '+href);
      if(anchor)check(chapters.get(id).toc.some(h=>h.id===anchor),'Missing anchor '+href);
    }else check(fs.existsSync(path.join(BOOK,href)),'Missing local file '+href);
  }
}
for(const file of Object.values(book.files)){
  const raw=fs.readFileSync(path.join(BOOK,file.href));
  const hash=crypto.createHash('sha256').update(raw).digest('hex');
  check(hash===file.sha256,'Snapshot hash mismatch '+file.path);
  const baseline=file.path==='.gitignore'?path.join(BOOK,'baseline/gitignore'):path.join(ROOT,file.path);
  if(fs.existsSync(baseline))check(raw.equals(fs.readFileSync(baseline)),'Baseline snapshot differs '+file.path);
}
check(Math.abs(math.enc(.5)-.7353569830524495)<1e-12,'sRGB midpoint');
check(Math.abs(math.dec(math.enc(.18))-.18)<1e-12,'sRGB round trip');
const beta=math.corrected([1/3,1/3,1/3],[1,1,2]);
check(beta.every((v,i)=>Math.abs(v-[.4,.4,.2][i])<1e-12),'Perspective reference weights');
const clipped=math.clipPolygon([[-1,0],[1,-1],[1,1]],p=>p[0]);
check(clipped.length===4&&clipped.every(p=>p[0]>=0),'Half-space intersection');
const mc=math.integrate(19,32768);
check(Math.abs(mc.estimate-1)<.03,'Monte Carlo integral should approach analytical value');
check(mc.estimate===math.integrate(19,32768).estimate,'Seed reproducibility');
console.log('BOOK_STATIC_OK '+JSON.stringify({chapters:book.chapters.length,han:book.han,localLinks,sourceExcerpts,assertions}));

class CDP {
  constructor(socket){this.socket=socket;this.id=0;this.pending=new Map();this.events=[];
    socket.addEventListener('message',event=>{
      const data=JSON.parse(event.data);
      if(data.id){const item=this.pending.get(data.id);if(item){clearTimeout(item.timer);this.pending.delete(data.id);data.error?item.reject(new Error(data.error.message)):item.resolve(data.result);}}
      else this.events.push(data);
    });
    socket.addEventListener('close',()=>{for(const item of this.pending.values()){clearTimeout(item.timer);item.reject(new Error('CDP closed'));}this.pending.clear();});
  }
  send(method,params={}){return new Promise((resolve,reject)=>{const id=++this.id,timer=setTimeout(()=>{this.pending.delete(id);reject(new Error('CDP timeout: '+method));},15000);this.pending.set(id,{resolve,reject,timer});this.socket.send(JSON.stringify({id,method,params}));});}
  async evaluate(expression){const r=await this.send('Runtime.evaluate',{expression,returnByValue:true,awaitPromise:true});if(r.exceptionDetails)throw new Error(r.exceptionDetails.exception?.description||r.exceptionDetails.text);return r.result.value;}
}

async function main(){
  const candidates=[
    'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe',
    'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe'
  ];
  const browser=process.env.ASTRA_BOOK_BROWSER||candidates.find(f=>fs.existsSync(f));
  check(browser&&fs.existsSync(browser),'Native Edge or Chrome required');
  const profile=path.join(ROOT,'.astra-book-browser-'+process.pid);
  check(!fs.existsSync(profile),'Isolated profile already exists');
  let child,cdp,stderr='',browserExit=null;
  const report={environment:ONLINE?'Native Windows / published web URL':'Native Windows / local file URL / network offline',url:ENTRY,browser,static:{chapters:27,han:book.han,snapshotFiles:Object.keys(book.files).length,localLinks,sourceExcerpts},chapters:[],sources:[],labs:[],screenshots:[]};
  try{
    child=spawn(browser,['--headless=new','--no-first-run','--no-default-browser-check','--disable-background-networking','--disable-component-update','--disable-sync','--disable-extensions','--remote-debugging-port=0','--user-data-dir='+profile,'about:blank'],{stdio:['ignore','ignore','pipe'],windowsHide:true});
    child.stderr.on('data',data=>{stderr=(stderr+data.toString()).slice(-6000);});
    child.on('error',error=>{stderr+=error.message;});
    child.on('exit',code=>{browserExit=code;});
    const active=path.join(profile,'DevToolsActivePort');
    await waitUntil(()=>fs.existsSync(active),'Browser did not expose debugging port');
    const port=fs.readFileSync(active,'utf8').split(/\r?\n/)[0];
    const tabs=await (await fetch('http://127.0.0.1:'+port+'/json/list')).json();
    const tab=tabs.find(t=>t.type==='page');
    check(Boolean(tab),'No browser page');
    const socket=new WebSocket(tab.webSocketDebuggerUrl);
    await new Promise((resolve,reject)=>{socket.addEventListener('open',resolve,{once:true});socket.addEventListener('error',reject,{once:true});});
    cdp=new CDP(socket);
    await cdp.send('Runtime.enable');await cdp.send('Page.enable');await cdp.send('Network.enable');
    if(!ONLINE)await cdp.send('Network.emulateNetworkConditions',{offline:true,latency:0,downloadThroughput:0,uploadThroughput:0});
    await cdp.send('Emulation.setDeviceMetricsOverride',{width:1600,height:1100,deviceScaleFactor:1,mobile:false});
    report.version=await cdp.send('Browser.getVersion');
    await cdp.send('Page.navigate',{url:ENTRY});
    await waitUntil(()=>cdp.evaluate('Boolean(window.BookReader && window.BookLabs && document.querySelector("#article h1"))'),'Reader did not load');
    check(await cdp.evaluate(ONLINE?'location.href.split("#")[0]==='+JSON.stringify(ENTRY):"location.protocol==='file:'&&location.pathname.endsWith('/book/index.html')"),'Expected reader entrypoint');
    await cdp.evaluate('document.documentElement.style.scrollBehavior="auto"');

    async function route(id){
      await cdp.evaluate('location.hash='+JSON.stringify('#ch/'+id));
      await waitUntil(()=>cdp.evaluate('BookReader.getState().chapter==='+JSON.stringify(id)),'Chapter route '+id);
      await cdp.evaluate('scrollTo({top:0,behavior:"instant"})');
    }
    async function screenshot(name){
      await delay(100);
      const result=await cdp.send('Page.captureScreenshot',{format:'png',captureBeyondViewport:false});
      fs.writeFileSync(path.join(CHECKS,name),Buffer.from(result.data,'base64'));report.screenshots.push(name);
    }
    async function images(){
      return cdp.evaluate(`(async()=>{const images=[...document.querySelectorAll('#article img')];images.forEach(i=>i.loading='eager');await Promise.all(images.map(i=>i.decode().catch(()=>{})));return images.map(i=>({src:i.getAttribute('src'),width:i.naturalWidth,height:i.naturalHeight,complete:i.complete}));})()`);
    }
    for(const chapter of book.chapters){
      await route(chapter.id);
      const foundImages=await images();
      const facts=await cdp.evaluate(`({
        id:BookReader.getState().chapter,title:document.querySelector('#article h1').textContent,
        overflow:document.documentElement.scrollWidth>innerWidth+1,
        labs:[...document.querySelectorAll('[data-lab]')].map(e=>({name:e.dataset.lab,ready:e.dataset.ready,state:e.dataset.state})),
        emptyCells:[...document.querySelectorAll('#article table')].filter(t=>[...t.tBodies[0].rows].some(r=>r.cells.length!==t.tHead.rows[0].cells.length)).length,
        unresolved:document.querySelector('#article').textContent.includes('交互实验正在准备')
      })`);
      check(facts.title===chapter.title,'Wrong chapter title '+chapter.id);
      check(!facts.overflow,'Desktop overflow '+chapter.id);
      check(facts.emptyCells===0,'Malformed table '+chapter.id);
      check(!facts.unresolved&&facts.labs.every(l=>l.ready==='true'),'Lab did not mount '+chapter.id);
      check(foundImages.every(i=>i.complete&&i.width>0&&i.height>0),'Image did not decode '+chapter.id);
      report.chapters.push({id:chapter.id,images:foundImages.length,labs:facts.labs.map(l=>l.name),desktopOverflow:false});
    }
    console.log('BOOK_CHAPTERS_OK '+report.chapters.length);

    for(const file of Object.values(book.files).filter(f=>f.kind==='text')){
      await cdp.evaluate('location.hash='+JSON.stringify('#source/'+file.path+':2'));
      await waitUntil(()=>cdp.evaluate('BookReader.getState().source==='+JSON.stringify(file.path)),'Source route '+file.path);
      const lines=await cdp.evaluate("[...document.querySelectorAll('.source-line code')].map(c=>c.textContent)");
      const expected=(file.text.endsWith('\n')?file.text.slice(0,-1):file.text).split('\n');
      check(lines.length===expected.length,'Source line count '+file.path);
      check(lines.every((line,i)=>line===(expected[i]||' ')),'Source text fidelity '+file.path);
      check(await cdp.evaluate("document.querySelector('.source-line.selected')?.id==='source-line-2'"),'Source line highlight '+file.path);
      check(await cdp.evaluate("document.querySelector('.source-actions a[download]').download")===file.path.split('/').at(-1),'Original download filename '+file.path);
      report.sources.push(file.path);
    }
    console.log('BOOK_SOURCES_OK '+report.sources.length);
    await cdp.evaluate("Object.defineProperty(navigator,'clipboard',{configurable:true,value:{writeText:async text=>{window.__bookCopied=text;}}});document.querySelector('#copy-source').click()");
    check(await cdp.evaluate('window.__bookCopied===BOOK.files[BookReader.getState().source].text'),'Copy complete source preserves text');
    await route('09-clipping');
    await cdp.evaluate("document.querySelector('.copy-code').click()");
    check(await cdp.evaluate("window.__bookCopied===document.querySelector('.code-card pre code').textContent"),'Copy source excerpt preserves text');
    await cdp.evaluate('delete navigator.clipboard;delete window.__bookCopied');

    const actions=[
      ['01-map','pipeline',"document.querySelector('[data-stage=\"4\"]').click()",'s.stage===4'],
      ['07-camera','camera',"set('distance',8)",'s.distance===8&&s.projectedWidth<80'],
      ['09-clipping','clipping',"set('x',220)",'s.inside&&s.vertices>=3'],
      ['10-raster','depth',"set('red',.8)",'s.winner==="青色"'],
      ['11-interpolation','barycentric',"set('w',4)",'s.w===4&&s.beta[2]<s.lambda[2]'],
      ['12-shadows','shadows',"set('bias',.25)",'s.visibility===1'],
      ['13-light','lighting',"set('bands',7)",'s.levels.length===7'],
      ['14-color','color',"set('t',.5)",'Math.abs(s.linearMixEncoded-.7353569830524495)<1e-10'],
      ['15-print','compare',"set('split',73)",'s.split===73'],
      ['18-performance','memory',"set('ss',1)",'s.mainBytes===1440*1080*46'],
      ['22-paths','montecarlo',"set('power',15)",'s.count===32768&&s.error<.03']
    ];
    for(const [id,name,action,expect] of actions){
      await route(id);
      const ok=await cdp.evaluate(`(()=>{const el=document.querySelector('[data-lab="${name}"]');const set=(k,v)=>{const input=el.querySelector('[data-control="'+k+'"]');input.value=v;input.dispatchEvent(new Event('input',{bubbles:true}));};${action};const s=JSON.parse(el.dataset.state);return {ok:${expect},state:s};})()`);
      check(ok.ok,'Lab interaction '+name+' '+JSON.stringify(ok.state));report.labs.push({name,state:ok.state,passed:true});
    }
    console.log('BOOK_LABS_OK '+report.labs.length);

    await route('11-interpolation');
    const anchor=chapters.get('11-interpolation').toc[2].id;
    await cdp.evaluate('location.hash='+JSON.stringify('#ch/11-interpolation/'+anchor));
    await delay(100);
    check(await cdp.evaluate(`Math.abs(document.getElementById(${JSON.stringify(anchor)}).getBoundingClientRect().top)<220`),'Chapter anchor scroll');
    await cdp.evaluate("document.querySelector('.skip-link').click()");
    check(await cdp.evaluate("BookReader.getState().chapter==='11-interpolation'&&document.activeElement.id==='reading'"),'Accessible skip link preserves chapter');
    await cdp.send('Input.dispatchKeyEvent',{type:'keyDown',key:'k',code:'KeyK',modifiers:2});
    await cdp.send('Input.dispatchKeyEvent',{type:'keyUp',key:'k',code:'KeyK',modifiers:2});
    check(await cdp.evaluate("document.querySelector('#search-dialog').open"),'Ctrl+K search');
    await cdp.evaluate("document.querySelector('#search-input').value='透视';document.querySelector('#search-input').dispatchEvent(new Event('input',{bubbles:true}))");
    check(await cdp.evaluate("document.querySelectorAll('.search-result').length>3"),'Chinese full-text search');
    check(await cdp.evaluate("BookReader.search('clip_triangle').some(r=>r.href.startsWith('#source/'))"),'Source search');
    await cdp.evaluate("document.querySelector('#search-close').click();document.querySelector('#read-toggle').click();document.querySelector('#font-plus').click();document.querySelector('#theme-toggle').click()");
    const saved=await cdp.evaluate('BookReader.getState()');
    check(saved.completed.includes('11-interpolation')&&saved.fontSize===19&&saved.theme==='dark','Reading controls');
    await cdp.evaluate('window.__beforeReload=true');
    await cdp.send('Page.reload');
    await waitUntil(()=>cdp.evaluate('!window.__beforeReload && Boolean(window.BookReader)'),'Reload');
    const restored=await cdp.evaluate('BookReader.getState()');
    check(restored.completed.includes('11-interpolation')&&restored.fontSize===19&&restored.theme==='dark','Local file preference persistence');
    await cdp.evaluate("document.querySelector('#font-minus').click();document.querySelector('#read-toggle').click()");
    await route('13-light');
    await cdp.evaluate("document.querySelector('[data-lab]').scrollIntoView({block:'start',behavior:'instant'})");
    await screenshot('desktop-dark-experiment.png');
    await cdp.evaluate("document.querySelector('#theme-toggle').click()");
    await route('00-opening');await images();await screenshot('desktop-opening.png');
    await route('15-print');await images();await cdp.evaluate("document.querySelector('[data-lab]').scrollIntoView({block:'start',behavior:'instant'})");await screenshot('desktop-comparison.png');
    await route('11-interpolation');await cdp.evaluate("document.querySelector('[data-lab]').scrollIntoView({block:'start',behavior:'instant'})");await screenshot('desktop-interpolation.png');

    await cdp.send('Emulation.setDeviceMetricsOverride',{width:390,height:844,deviceScaleFactor:1,mobile:true});
    await cdp.send('Emulation.setTouchEmulationEnabled',{enabled:true});
    for(const chapter of book.chapters){
      await route(chapter.id);
      check(await cdp.evaluate('document.documentElement.scrollWidth<=innerWidth+1'),'Mobile overflow '+chapter.id);
      check(await cdp.evaluate('document.querySelector("#article").getBoundingClientRect().width>300'),'Mobile reading width '+chapter.id);
    }
    await route('00-opening');await images();await screenshot('mobile-opening.png');
    await cdp.evaluate("document.querySelector('#menu-toggle').click()");
    check(await cdp.evaluate("document.body.classList.contains('menu-open')&&!document.querySelector('#scrim').hidden"),'Mobile menu');
    await screenshot('mobile-navigation.png');
    await cdp.evaluate("document.querySelector('.chapter-link.active').click()");
    check(await cdp.evaluate("!document.body.classList.contains('menu-open')"),'Tapping current chapter closes mobile menu');
    await cdp.evaluate("document.querySelector('#menu-toggle').click()");
    await cdp.evaluate("document.querySelector('#search-open').click()");
    check(await cdp.evaluate("document.querySelector('#search-dialog').getBoundingClientRect().width<390"),'Mobile search layout');
    await cdp.evaluate("document.querySelector('#search-close').click();document.querySelector('#scrim').click()");
    await route('11-interpolation');await cdp.evaluate("document.querySelector('[data-lab]').scrollIntoView({block:'start',behavior:'instant'})");await screenshot('mobile-interpolation.png');
    report.mobile={width:390,height:844,chaptersChecked:27,overflow:false,menu:true,search:true};
    await cdp.send('Emulation.setDeviceMetricsOverride',{width:1600,height:1100,deviceScaleFactor:1,mobile:false});
    await cdp.send('Emulation.setEmulatedMedia',{media:'print'});
    check(await cdp.evaluate("getComputedStyle(document.querySelector('#sidebar')).display==='none'"),'Print hides navigation');
    check(await cdp.evaluate("getComputedStyle(document.querySelector('#article')).fontSize!=='0px'"),'Print retains chapter');
    await cdp.send('Emulation.setEmulatedMedia',{media:''});
    const external=cdp.events.filter(e=>e.method==='Network.requestWillBeSent'&&/^https?:/.test(e.params.request.url)&&(!ONLINE||new URL(e.params.request.url).origin!==new URL(ENTRY).origin));
    const exceptions=cdp.events.filter(e=>e.method==='Runtime.exceptionThrown').map(e=>e.params.exceptionDetails.exception?.description||e.params.exceptionDetails.text);
    const failedFiles=cdp.events.filter(e=>e.method==='Network.loadingFailed');
    check(external.length===0,'Reader made an external network request');
    check(exceptions.length===0,'Browser exceptions '+JSON.stringify(exceptions));
    check(failedFiles.length===0,'Local resource failure '+JSON.stringify(failedFiles));
    report.network={offline:!ONLINE,externalRequests:external.length,resourceFailures:failedFiles.length,javascriptExceptions:exceptions.length};
    if(!ONLINE)report.offline={externalRequests:external.length,resourceFailures:failedFiles.length,javascriptExceptions:exceptions.length};
    report.preferences={fontSize:true,theme:true,completed:true,persistAfterReload:true};
    report.search={chinese:true,source:true,shortcut:true};
    report.copy={source:true,excerpt:true,clipboardAdapterStubbed:true};
    report.printCurrentChapter=true;
    report.assertions=assertions;
    if(!ONLINE)report.verifiedFiles=Object.fromEntries(['index.html','data.js','reader.js','labs.js','style.css','toc.json'].map(name=>[name,crypto.createHash('sha256').update(fs.readFileSync(path.join(BOOK,name))).digest('hex')]));
    await cdp.send('Browser.close').catch(()=>{});
    await waitUntil(()=>child.exitCode!==null,'Browser did not exit',10000);
    check(child.exitCode===0,'Browser exit code '+child.exitCode);
    report.browserExitCode=child.exitCode;
    report.assertions=assertions;
    report.passed=true;
    fs.writeFileSync(path.join(CHECKS,'browser-report.json'),JSON.stringify(report,null,2)+'\n');
    console.log('BOOK_BROWSER_OK '+JSON.stringify({browser:report.version.product,chapters:27,sources:report.sources.length,labs:report.labs.length,offline:!ONLINE,mobile:true,assertions,exitCode:child.exitCode}));
  }catch(error){
    fs.writeFileSync(path.join(CHECKS,'browser-failure.json'),JSON.stringify({error:error.stack,assertions,browserExit,stderr},null,2));
    if(cdp)try{const result=await cdp.send('Page.captureScreenshot',{format:'png'});fs.writeFileSync(path.join(CHECKS,'failure.png'),Buffer.from(result.data,'base64'));}catch{}
    throw error;
  }finally{
    if(child&&child.exitCode===null){if(cdp)await cdp.send('Browser.close').catch(()=>{});if(child.exitCode===null)child.kill();await delay(500);}
    for(let attempt=0;attempt<8;attempt++){try{fs.rmSync(profile,{recursive:true,force:true});break;}catch{await delay(250);}}
  }
}
main().catch(error=>{console.error(error.stack);process.exitCode=1;});
