## 能读取配置，才刚刚开始

渲染回调可以通过 `depsgraph.scene_eval` 取得当前求值后的场景。公共渲染配置在 `scene.render`，色彩管理在 `scene.view_settings`，相机在 `scene.camera`，引擎专属设置则由相应插件注册。读取一个属性与实现这个属性的语义，是两件需要分别验证的工作。

例如 `scene.render.film_transparent` 能被读取，但当前 Astra 在输出数组中把 Alpha 填为 1，因此始终给出不透明纸底。Cycles 的采样数也可以在 Cycles 已注册时读取，却不会自动改变 Astra 的超采样倍数。Astra 采用的是自己定义的 `scene.astra_press.supersampling`。

## 用一张表说明支持程度

| 配置 | 入口 | 当前实现 |
| --- | --- | --- |
| 分辨率与比例 | `scene.render.resolution_x/y`、`resolution_percentage` | 计算最终像素尺寸 |
| 像素宽高比 | `pixel_aspect_x/y` | 传入相机投影矩阵计算 |
| 相机类型与裁剪 | `scene.camera.data` | 支持 PERSP、ORTHO 与投影裁剪 |
| 输出路径与图像格式 | `filepath`、`image_settings` | 交给 Blender 输出流程 |
| 色彩显示 | `scene.view_settings` | 交给 Blender 显示与保存阶段 |
| 渲染区域 | `scene.render.use_border` | 显式报错，要求关闭 |
| 景深与运动模糊 | 相机、场景相关设置 | 未实现 |
| 世界节点与 HDRI | `scene.world` | Demo 设置了 World，Astra 当前不求值 |
| 光源 | 场景中的 Sun | 读取首个可渲染 Sun，强度上限为 2 |

最后两行很重要。同一个场景送给 Cycles 和 Astra，可以有相同的输入对象，却由两个引擎实现不同的语义。World 在 Cycles 中参与照明，Astra 则使用纸色与自己的阴影颜料。这正是比较图像时必须知道的边界。

## 为艺术参数建立自己的类型

:::code astra_press/__init__.py#AstraSettings

`IntProperty`、`FloatProperty`、`EnumProperty` 不只负责存放值，也定义了用户能怎样编辑它们。色阶至少为 2，描边宽度允许为 0，阴影分辨率提供几个明确选项。让参数名描述用户看到的效果，比暴露内部数组或实现细节更有用。

参数应有单位。`outline_width` 和 `registration` 的单位是最终图像像素；在超采样缓冲中绘制时需要乘以倍数。`grain` 是颜色扰动的幅度，`shadow_size` 是阴影贴图边长。一个“强度”滑杆如果在不同分辨率下表现完全不同，通常说明单位没有被认真定义。

## 哪些东西会进 .blend

挂在 Scene、Material 等数据块上的自定义属性可以随工程保存。Python 类的代码和进程内注册状态不会因为保存 `.blend` 就自动变成已安装插件。重新打开文件时，需要先有定义这些属性和引擎的代码，才能按预期使用它们。

纯运行时数据则不应全部塞进场景。当前代码把渲染是否成功、耗时和三角形数写为几个自定义属性，便于 demo 检查；完整 G-buffer、阴影数组和临时网格都不持久化。这避免工程文件被大量可重算的中间结果撑大。

:::note 未来的配置转换层
当内核迁移到 C++ 时，可以先把 Blender 配置转换成明确的数据对象，例如 `RenderOptions(width, height, camera, style, output_passes)`。对每个选项定义支持程度、默认值、范围及错误行为。这样 UI 更新和内核升级就有了可检查的边界。
:::

:::exercise 把 film_transparent 直接读出来，功能就完成了吗？
还没有。你需要让未覆盖像素输出合适的 Alpha，决定纸纹是否保留，处理轮廓扩张到背景的区域，并明确预乘 Alpha 的约定。还要检查透明物体、阴影捕捉和下采样时颜色与 Alpha 的共同处理。这些都不是一个布尔值能够代替的实现。
:::
