## 把容易混淆的词放在一起

| 术语 | 本书中的含义 |
| --- | --- |
| RenderEngine | Blender 调用自定义引擎的宿主接口类型 |
| bpy / RNA | Blender Python API 及其数据访问体系 |
| Dependency Graph | 按关系求值后的场景视图，简称 depsgraph |
| Object / Mesh | 场景中的一次对象与可被共享的网格数据 |
| Instance | 一个源数据通过独立变换在场景中的一次出现 |
| Corner / Loop | 面角，用于法线、UV 等可在接缝处分离的属性 |
| Clip Space | 透视除法前的四分量齐次裁剪空间 |
| NDC | 裁剪坐标除以 w 后的标准化设备坐标 |
| Rasterization | 把连续图元转成离散样本覆盖与属性 |
| Fragment | 光栅化产生的候选样本，未必通过深度测试 |
| Z-buffer | 每个样本的已知最近深度 |
| G-buffer | 可见表面的几何与材质信息缓冲 |
| Barycentric Coordinates | 三角形内的重心坐标，权重和为 1 |
| Perspective Correction | 利用顶点 w 修正屏幕属性插值 |
| Shadow Map | 从光源方向保存的最近深度图 |
| PCF | 对多个深度比较结果求平均的阴影过滤方法 |
| Bias | 为缓解数值误判而加入的比较或位置偏移 |
| Linear RGB | 按所选基色表示、与光量线性相关的 RGB |
| sRGB Encoding | 用非线性传递函数编码的显示颜色表示 |
| View Transform | 把场景值映射到观看条件下显示结果的变换 |
| Supersampling | 增加空间采样后滤波，项目 2× 实为四个子样本 |
| BSDF / BRDF | 描述表面散射分布；BRDF 只描述反射部分 |
| Radiance | 辐亮度，沿方向传播的光量描述 |
| PDF | 概率密度，采样估计中的权重分母之一 |
| BVH | 包围体层次结构，用于减少求交候选 |
| MIS | 多重重要性采样，组合不同采样策略 |
| Throughput | 路径走到当前顶点时累计的贡献权重 |
| ABI | 二进制接口约定，原生扩展兼容性的一部分 |
| GIL | CPython 的全局解释器锁，不等于 Blender 线程安全 |
| Fake User | 即使没有正常引用，也保留数据块的用户标记 |

## 常用公式速查

:::equation 变换与插值
p_clip = P · V · M · p_local
p_ndc = p_clip.xyz / p_clip.w
n_world = normalize(M_linear⁻ᵀ · n_local)
βᵢ = (λᵢ/wᵢ) / Σ(λⱼ/wⱼ)
z_ndc(P) = Σ λᵢ z_ndc,i
:::

:::equation 裁剪、光照与采样
t_clip = dA / (dA - dB)
Lambert 朝向信号 = max(n·l, 0)
可见性比较 = receiver_z ≤ shadow_z + bias
蒙特卡洛积分估计 = (1/N) Σ f(xᵢ)/p(xᵢ)
主 G-buffer 字节数 = width × height × scale² × 46
:::

公式必须和空间、单位及前提一起使用。法线逆转置中的矩阵不包括投影；NDC 深度的 λ 是屏幕权重；蒙特卡洛的 p 必须与积分使用同一测度。脱离这些条件，正确公式也会被用错。

## 接口与宿主：先读官方

- [Blender 4.5 RenderEngine](https://docs.blender.org/api/4.5/bpy.types.RenderEngine.html)：渲染回调、结果写回、进度与视口相关接口。
- [Blender 4.5 Depsgraph](https://docs.blender.org/api/4.5/bpy.types.Depsgraph.html)：求值对象、实例与临时网格示例。
- [Blender 4.5 Object](https://docs.blender.org/api/4.5/bpy.types.Object.html)：对象、to_mesh 和相机矩阵。
- [Blender 4.5 颜色管理手册](https://docs.blender.org/manual/zh-hans/4.5/render/color_management.html)：场景线性、视图变换与输出。
- [Blender Python 线程注意事项](https://docs.blender.org/api/main/info_gotchas_threading.html)：主线文档，开发时应再核对目标版本限制。
- [Cycles 源码布局](https://developer.blender.org/docs/features/cycles/source_layout/)：从适配层走向成熟渲染系统的目录地图。

## 算法与系统：按需要深入

- [OpenGL 4.6 Core 规范](https://registry.khronos.org/OpenGL/specs/gl/glspec46.core.pdf)：裁剪、坐标与光栅化规则的严谨参考。Astra 借用部分约定，不是 OpenGL 一致性实现。
- [PBRT 第四版在线书](https://www.pbr-book.org/4ed/contents)：几何、采样、材质、光传输与系统设计。适合在已有小渲染器之后逐章扩展。
- [PBRT 路径追踪器](https://pbr-book.org/4ed/Light_Transport_I_Surface_Reflection/A_Better_Path_Tracer)：直接光、MIS 与路径终止。
- [pybind11 NumPy 接口](https://pybind11.readthedocs.io/en/stable/advanced/pycpp/numpy.html)：数组、缓冲、stride 和所有权边界。
- [Blender 4.5 Cycles Python 引擎封装](https://github.com/blender/blender/blob/blender-v4.5-release/intern/cycles/blender/addon/engine.py)：观察宿主与原生模块的分工。
- [BlendLuxCore 基础引擎](https://github.com/LuxCoreRender/BlendLuxCore/blob/master/engine/base.py)：另一种实际 Blender 集成结构。

这些外部资料没有被复制成离线整书。正文的算法解释围绕本项目源码、可手算的例子和自行编写的交互实验展开；外链用于核对接口和继续深入。

## 再回到第一张图

现在可以把画面中的每种现象接回代码：球面的色阶来自法线和光方向，拱门内侧的遮挡来自阴影图，细线来自覆盖采样和超采样，墨边来自 id 与法线差异，纸感来自明确坐标域中的风格函数。

而一张可靠的成品背后，还有依赖图求值、数组契约、错误传播、保存与重开验证。读者可以从档案馆拿走同一份代码，关掉一种效果，验证一种假设，再让下一张图拥有自己的表达。
