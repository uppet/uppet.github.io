## .blend 保存场景，ZIP 提供行为

`quiet_objects.blend` 保存对象、网格、材质、相机、灯光和属性。`astra_press.zip` 提供引擎代码。打开一个记录着 `ASTRA_PRESS` 引擎标识的文件，不会自动让缺失的 Python 类出现；要继续渲染，应安装并启用插件，或在受控脚本中手动注册。

原型包采用 `astra_press/__init__.py` 加 `core.py` 的目录结构，包含 `bl_info`，属于传统 Python add-on。它不是 Blender 内置引擎，也不是新式扩展清单系统的完整示范。针对本机 Blender 4.5.1，使用偏好设置中的从磁盘安装入口选择 ZIP，再启用 Astra Press。

## 为什么不用安装也能演示

`render_demo.py` 把项目目录加入 `sys.path`，导入 `astra_press` 后调用 `register()`。这是当前进程中的注册，不会替读者永久安装插件。文件保存和进程退出后，之后启动的 Blender 仍需通过安装或脚本获得同一份实现。

若在普通 Blender 会话中已经启用了插件，再无条件运行 demo 中的 `register()`，当前版本会报重复注册错误。测试中实际见过 `AstraSettings` 已注册的 ValueError。本书没有修改这份基线代码来掩盖这个限制；第三章说明了清理、重载和模块缓存的正确排查方向。

## 一个真实失败：pack 了，为什么重开还没了

演示将成品加载成 Image 数据块，调用 `pack()` 把像素文件打包进 .blend。最初的检查发现，新进程重新打开场景后找不到那张图片。原因是它没有被材质、编辑器等有效用户引用；打包文件内容与保留数据块是两件事。

修复是为成品图片设置 `use_fake_user=True`，为说明 Text 数据块也设置 fake user，再保存文件。假用户告诉 Blender 即使没有正常引用，也保留这个数据块。随后重新打开检查内嵌图像，并重渲染，验证链路通过。

```python
finished_print = bpy.data.images.load(str(output / 'astra_press.png'),
                                      check_existing=False)
finished_print.name = 'Astra Press / Finished Print'
finished_print.use_fake_user = True
finished_print.pack()
bpy.ops.wm.save_as_mainfile(filepath=str(output / 'quiet_objects.blend'))
```

这段节选对应现有 `main`，完整实现可在[源码浏览器](#source/render_demo.py)中查看。经验不是“永远给所有数据加 fake user”，而是弄清哪些资料需要独立留存，再通过关闭与重开验证。滥用 fake user 会让不用的资源也长期留在文件里。

## 把交付结果做成可以核对的清单

| 产物 | 它证明或提供什么 |
| --- | --- |
| astra_press.zip | 可分发的插件源码包 |
| quiet_objects.blend | 可编辑的演示场景与内嵌成品 |
| astra_press.png | 自定义引擎完成的高分辨率图像 |
| cycles_reference.png | 相同场景的风格参照 |
| compare.html | 原项目的本地对照滑块 |
| astra_press_report.json | 版本、尺寸、三角形数和计时记录 |
| checks/package_report.json | ZIP 导入、重开、重渲染检查结果 |
| checks/reopened_scene.png | 包验证实际生成的小尺寸图像 |

报告是观察记录，源码是机制，两者都需要保存。本书档案馆还为每个快照文件计算 SHA-256，读者可以验证自己拿到的文件是否与书中分析的一致。

### 故障排查按边界进行

引擎列表里没有 Astra，先看安装和注册；有引擎但无对象，查依赖图导出数量；有形状但颜色不对，查材质提取与颜色空间；渲染成功但下次打不开，查路径、数据块引用和包内容。按系统边界排查，比反复重装 Blender 更有信息量。

:::exercise 为什么包验证要确认 astra_press.__file__ 中包含 .zip？
因为当前工作目录可能正好有同名源码包。若测试实际导入的是工作目录版本，就算 ZIP 缺少 core.py 也可能被蒙混过关。确认导入来源，让测试对象确实是准备交付的包。
:::

到这里，一次渲染不只是屏幕上出现图像，而是包含输入、实现、结果、验证和可重开的场景。这些环节让下一位读者能够继续开发。
