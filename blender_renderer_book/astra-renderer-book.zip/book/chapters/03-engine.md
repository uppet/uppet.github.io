## 一个 Python 类怎样成为渲染引擎

Blender 给出了 `bpy.types.RenderEngine` 这个扩展点。我们定义它的子类，设置内部标识和界面名称，再通过 `bpy.utils.register_class()` 注册。内部标识 `ASTRA_PRESS` 对应场景的 `scene.render.engine` 值；显示名称 `Astra Press` 则出现在用户界面里。

```python
class MyEngine(bpy.types.RenderEngine):
    bl_idname = "MY_ENGINE"
    bl_label = "My Engine"

    def render(self, depsgraph):
        # 在这里读取场景并计算图像。
        pass

bpy.utils.register_class(MyEngine)
bpy.context.scene.render.engine = "MY_ENGINE"
```

这只是展示注册关系的骨架，没有输出像素。真正接入必须实现结果提交；完整过程见第 16 章。引擎实例也不应被当作整个应用唯一的单例：最终渲染、材质预览和多个视口可能有不同生命周期。Astra 关闭了材质预览，并且把每次最终渲染所需的数组限制在回调生命周期内。

## 安装与注册分别做什么

安装把 Python 包及依赖放到 Blender 能发现的位置。启用插件时，Blender 加载模块并调用其 `register()`。Demo 直接把项目根目录放进 `sys.path`，导入源码并调用同一个函数，因此能在没有永久安装插件时使用引擎。

:::code astra_press/__init__.py#register

这里注册的不只有渲染器，还包括场景属性、材质属性和面板。`PointerProperty` 将我们的设置挂到 Blender 类型上。注册顺序必须满足依赖：先有 `PropertyGroup` 类，才能建立指向它的属性。注销时按相反顺序释放，并撤销面板兼容性修改。

## 重复运行为什么会报错

项目完成后，我们专门在 Windows Blender 4.5.1 中连续执行了两次 `astra_press.register()`。第二次立即失败，实际信息是：

```text
ValueError: register_class(...): already registered as a subclass 'AstraSettings'
```

这不是安装文件相互覆盖，而是当前进程中已有同名注册类。当前快照没有重复注册保护。带 `--factory-startup` 的独立后台流程能避开普通用户插件的自动启用；在已经启用 Astra 的界面中再次执行 demo，则会遇到这条失败路径。

还有一层容易忽略：Python 会缓存已导入模块。把项目源码目录放到 `sys.path` 最前面，不能让 `import astra_press` 自动替换 `sys.modules` 中已有的安装版本。调试时要检查 `astra_press.__file__`，明确当前使用的是哪个副本。

:::pitfall 不要把所有注册错误吞掉
用 `try: register(); except: pass` 看起来能让第二次运行继续，但它会同时掩盖真正的属性类型错误和部分注册失败。扩展版本应明确选择“复用已加载版本”或“卸载旧版本、重新载入开发源码”，并为两条路径分别测试。
:::

## 生命周期里需要考虑的接口

| 接口 | 适合承担的工作 | 当前 Astra |
| --- | --- | --- |
| `update()` | 为渲染同步或准备场景 | 合并在 `render()` 里完成 |
| `render()` | 最终图像与结果提交 | 已实现 |
| `view_update()` | 处理视口与场景变化 | 未实现 |
| `view_draw()` | 快速绘制已有视口结果 | 未实现 |
| `update_render_passes()` | 宣告额外输出通道 | 当前仅使用 Combined |
| `test_break()` | 查询用户取消请求 | 在多处循环中使用 |

`view_draw()` 的未来实现应保持轻量，把耗时的场景同步和计算安排到清楚的调度边界。仅仅添加方法名，并不会自动得到流畅、可取消、不会访问失效对象的实时视口。

:::exercise 如果只想在已启用插件的会话中重画一帧，还需要 register 吗？
不需要。已经注册的引擎可直接通过 `scene.render.engine = "ASTRA_PRESS"` 选择，再调用渲染操作器。只有要加载尚未注册的实现，或者有计划地替换当前实现时，才涉及注册生命周期。当前 demo 还包含清空并重建场景的逻辑，不能把它等同于单纯的“重画一帧”。
:::

官方接口：[Blender 4.5 RenderEngine](https://docs.blender.org/api/4.5/bpy.types.RenderEngine.html)。
