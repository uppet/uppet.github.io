## 书中的结论都有对应文件

这里收录本次制书前的全部项目源码与有效交付产物，包括插件、演示脚本、测试、README、场景、两张成品、对照网页和检查报告。自动生成的 Python 缓存、编辑器临时文件与备份不是独立交付内容，未作为档案条目。

点击源码可在书内逐行浏览、复制和搜索；点击图片或 HTML 可直接打开；ZIP 与 .blend 提供下载。每个条目列出字节数和 SHA-256。原始 .blend 仍需要 Blender 打开，但本书的正文、图片、图解和源代码阅读只需要浏览器。

:::archive

## 怎样从一个函数跳回整条调用链

源码浏览器保留完整文件与原始行号。章节中的“查看完整源码”链接会定位到对应行；地址中的 `#source/astra_press/core.py:79` 也可以直接分享给持有本书目录的人。行号属于当前快照，修改源文件后不保证继续对应。

推荐沿下面的路线读一遍：

1. [render_demo.py](#source/render_demo.py) 的 main：注册、建场景、渲染、比较、保存、打包。
2. [__init__.py](#source/astra_press/__init__.py) 的 AstraRenderEngine.render：把 Blender 配置和求值数据交给核心。
3. [core.py](#source/astra_press/core.py) 的 render：主光栅、阴影、风格、降采样、RGBA。
4. 同文件的 clip_triangle、fragments、rasterize、visibility、shade：逐层展开算法。
5. [verify_renderer.py](#source/tests/verify_renderer.py) 与 [verify_package.py](#source/tests/verify_package.py)：检查算法事实和交付路径。

## 这本本地书如何工作

正文在 `chapters/*.md`，目录在 `toc.json`。`build_book.py` 使用 Python 标准库生成预先嵌入的 `data.js`，其中包含章节 HTML、搜索文本、完整源码和文件清单。阅读器使用普通 script 标签加载，无需 fetch、ES module、CDN 或本地服务器。

`reader.js` 管理目录、搜索、源码路由、主题和进度；`labs.js` 提供 Canvas 与 DOM 教学实验；`style.css` 控制排版和打印。图像来自快照内的真实产物。数学实验使用本地 JavaScript 计算，书页不会调用 Blender，也不会偷偷向网络发送场景。

阅读记录、字体大小和主题使用浏览器本地存储。不同浏览器、隐私模式、目录迁移或浏览器对 file URL 的策略可能让记录不能共享；即使存储不可用，正文和实验仍可阅读。

### 重新构建

第一次构建会从项目根目录复制列出的基线文件。后续构建保留已有 `project/` 快照，只更新正文、数据和项目 ZIP。若要制作另一个版本，请显式管理新的快照目录，避免无意覆盖本书所引用的证据。

```bash
"/c/Program Files/Blender Foundation/Blender 4.5/blender.exe" --background --factory-startup --python-exit-code 1 --python book/build_book.py
```

构建脚本本身不导入 bpy，普通 Python 3 也可执行。使用 Blender 自带 Python 是为了沿用本项目已验证的环境。书的便携压缩包同时保留正文、阅读器和构建源码，读者可以继续编辑成自己的实验手册。

## 离线与外部参考

正文和附带资料可离线阅读。参考文献链接指向 Blender、Khronos、PBRT 等官方站点，访问它们需要网络。它们是进一步阅读入口，不是本书加载内容所需的资源。

本书说明的是 Blender 4.5.1 LTS 下这份可运行原型。外部文档可能随版本更新；对接口行为有疑问时，应优先对照本书快照、本机版本和最小验证命令，再查相应版本的官方文档。
