## 先确认谁在执行代码

本项目所在目录在 Windows 的 D 盘，协作命令行位于 WSL。`/mnt/d/bld/astra_render` 与 `D:\bld\astra_render` 指向同一个目录，但它们属于不同的路径语法。Windows Git Bash 中通常写作 `/d/bld/astra_render`。把这三种拼法混用，是自动化脚本很常见的第一种失败。

原项目的 Windows 构建、测试和 Blender 启动通过 `delegate_runner` 执行，工作目录使用 `D:\bld\astra_render`，Shell 使用 `c:/Apps/Git/bin/bash.exe`。WSL 负责读写代码文件。读者直接在 Windows Git Bash 或终端运行时，不需要安装这个委托工具；它只是本次协作环境中的执行通道。

## 使用 Blender 自己的 Python

插件依赖 `bpy`，所以示例从 Blender 可执行文件启动。普通系统 Python 未必有 `bpy`，版本和二进制依赖也未必与 Blender 一致。下面是已使用的完整命令，路径含空格的可执行文件必须加引号。

```bash
cd /d/bld/astra_render
"/c/Program Files/Blender Foundation/Blender 4.5/blender.exe" \
  --background --factory-startup --python-exit-code 1 \
  --python render_demo.py -- --width 1440 --compare
```

`--background` 启动后台进程；`--factory-startup` 使用出厂启动状态，避免用户启动文件和偏好影响脚本；`--python-exit-code 1` 让命令行执行的 Python 脚本异常成为可检测的非零退出码；`--python` 指定脚本。最后一个 `--` 后的参数交给 `render_demo.py` 自己解析。

参数有顺序。先加载文件还是先注册脚本，会改变后续操作的上下文。脚本运行时既要知道当前工作目录，也要知道自身文件的位置。本项目用 `Path(__file__).resolve().parent` 定位项目根目录，输出路径因此不依赖你从哪个目录启动命令。

:::note 出厂启动只影响这次进程
这里没有把用户的偏好文件重置或覆盖。后台 demo 在独立进程中创建自己的场景。若把同一段建模代码粘到已有交互会话里运行，`select_all` 和 `delete` 会操作当前场景，运行前应保留自己的工作。
:::

## 先做环境探针

```python
import bpy
import sys
import numpy as np

print(bpy.app.version_string)
print(sys.version)
print(np.__version__)
```

本次探针得到 Blender 4.5.1 LTS、Python 3.11.11 和 NumPy 1.26.4。原型只使用 Blender 附带的 NumPy，没有额外安装 GPU SDK、图像生成模型或 Python 包。这让“第一次运行”只有一个主要变量：你是否正在使用目标 Blender。

同样的思路适用于未来原生模块。先确认解释器版本、CPU 架构、模块实际路径和依赖库是否能加载，再调试渲染算法。DLL 加载失败与阴影算法错误属于不同层，混在一起只会增加排查成本。

## 进程结束才是一次运行结束

后台渲染可能输出很多状态行，也可能一段时间没有输出。没有新日志不代表进程失败。记录任务标识，等待终态，再检查退出码；不要因为日志安静就启动第二份相同工作。

当前 demo 还会检查 PNG 是否存在、尺寸是否正确、像素是否有限以及画面是否明显非空。这很有必要：引擎回调中的异常未必按你想象的方式传回最外层脚本，所以还需要检查 `_astra_render_ok`。退出码、结果文件和内容验证共同构成一次可靠的完成判断。

| 现象 | 第一项检查 |
| --- | --- |
| 找不到 `bpy` | 是否由 Blender 内置解释器运行 |
| 找不到项目模块 | 脚本路径、`sys.path` 和实际导入文件 |
| 找不到可执行文件 | Windows / WSL / Git Bash 路径是否混用 |
| 有错误日志但退出码为零 | 是否缺少脚本错误码与显式完成断言 |
| 出现 warning 但成功出图 | 判断警告是否影响场景，不把 warning 自动当失败 |

:::exercise 把命令搬到另一台机器，需要改哪里？
至少改 Blender 可执行文件的位置和项目根目录。脚本内部输出位置通过 `__file__` 推导，通常无需改。还要确认 Blender 版本及 NumPy 环境。若使用书中的项目 ZIP，先解压，再把工作目录指向解压后的工程根目录。
:::

继续阅读：[Blender 启动与用户偏好的行为](https://docs.blender.org/api/4.4/info_advanced_blender_as_bpy.html)。
