## 先保住已经清楚的边界

当前核心只依赖 NumPy，不依赖 bpy。这意味着未来可以让 Python 继续管理 Blender 生命周期、属性面板、场景求值和结果回传，把连续数组交给原生库计算。需要移植的是明确的计算接口，而不是先把每一个 Python 文件翻译成 C++。

:::extension 本章是扩展设计
仓库没有 C++、CUDA、Vulkan 或其他原生后端。本章提出可以从现有 Geometry 和 render 接口继续发展的方案，示意代码不是已经编译验证的交付物。
:::

## 业内接口说明了什么

Blender 4.5 的 Cycles Python 层有 `CyclesRender` 这个 RenderEngine 子类，`engine.py` 再进入 `_cycles` 原生模块。这说明 Python 做宿主集成、原生层负责大量计算是一条现实路径。[Cycles 的引擎封装](https://github.com/blender/blender/blob/blender-v4.5-release/intern/cycles/blender/addon/engine.py) 可用来查看边界，而不是照搬内部指针协议。

LuxCore 的 Blender 集成也能看到 RenderEngine 与 pyluxcore 的配合。[BlendLuxCore 的基础引擎实现](https://github.com/LuxCoreRender/BlendLuxCore/blob/master/engine/base.py) 是另一份可读案例。不同项目还可能使用进程通信、场景文件导出或 Hydra，并不存在“所有商业渲染器都必须由 Python 逐项调用同一套 C++ 接口”的规则。

## 设计一次粗粒度调用

一个合理的接口接收场景快照、相机与渲染选项，返回像素或启动渲染会话：

```text
SceneSnapshot
  meshes: positions, corner_normals, indices, material_ids
  instances: mesh_id, transform, visibility
  materials, lights, camera

RenderOptions
  width, height, samples, seed, supported_features

RenderSession
  start(snapshot, options)
  poll_progress()
  request_cancel()
  read_result()
```

如果 Python 对每个三角形甚至每个像素调用一次 C++，跨语言开销可能仍然很大。应让原生层内部执行密集循环，并一次传递足够大的数据块。

## 数组的形状只是契约的一部分

原生绑定还应检查 dtype、维数、连续性、stride、写权限和长度溢出。一个 NumPy 切片看似同样是 `N×3`，内存却可能不是连续排列。对 float64 数组取出地址后按 float32 解读，会产生完全错误的数据。

pybind11 的 `py::array_t`、缓冲协议和 stride 信息能帮助建立这些检查；是否自动转换或复制应明确决定。[官方 NumPy 绑定说明](https://pybind11.readthedocs.io/en/stable/advanced/pycpp/numpy.html) 给出了相关接口。自动转换方便原型，严格拒绝不符合条件的数组更容易发现性能与数据错误。

生命周期同样关键：原生任务还在读数组时，Python 侧不能释放、重排或写坏它。零拷贝只意味着没有复制内容，不意味着数据自动拥有正确寿命。可选择由会话持有 Python 所有者引用，或在开始时复制进引擎自己的不可变场景。

## 线程、GIL 与 Blender 是三件事

密集原生计算可以在合适范围内释放 GIL，让其他 Python 工作有机会执行。但释放 GIL 不会让 bpy 变成线程安全。工作线程应处理已提取的数据，通过受控队列或宿主允许的回调回传进度，避免直接读写场景。

Blender 官方明确提醒 Python 线程使用的限制；做后台任务时，应按其[线程注意事项](https://docs.blender.org/api/main/info_gotchas_threading.html)设计生命周期。取消标志可以是原生原子变量，像素块则在明确同步后交换。不要一边让 Blender 修改网格，一边让原生线程读同一块不受保护的内存。

### 不要把 as_pointer 当成公共场景文件格式

内置或紧密配套的组件可能直接传 Blender 内部地址，但这些结构受版本、编译方式和对象生命周期约束。给独立插件复制这种写法，会把兼容性与崩溃风险带进项目。普通插件优先通过公开 API 提取自己定义的数据协议。

## Windows 上的二进制交付

本机 Blender 使用 Python 3.11.11。原生扩展的架构、CPython ABI、编译运行库和依赖 DLL 必须匹配目标 Blender；系统 Python 能导入，不代表 Blender 内也能导入。发布前应在干净进程验证 `import`、最小计算、完整渲染、取消和卸载。

GPU 后端还多了设备选择、缓冲上传、着色器编译、同步和显存预算。先让数据长期留在设备上，再讨论更多并行。若场景静态但每帧都完整重传，大量计算优化会被传输成本抵消。

:::exercise 如果只允许先移植一个模块，选哪里？
先测量。若逐三角形控制占主要时间，可移植裁剪与光栅循环；若像素着色占主导，可先移植 shade；若导出与复制占主导，应先改善数据更新协议。保留现有 Python 核心作为小场景参考实现，让迁移结果可以逐项对照。
:::
