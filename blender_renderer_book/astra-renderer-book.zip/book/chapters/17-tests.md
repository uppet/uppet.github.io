## 图像不只有“看起来对”这一种证据

渲染器很适合视觉检查，但最有价值的自动测试常常不需要漂亮模型。一个三角形、一块遮挡板、一个已知矩阵，就能构造有明确答案的问题。测试不是把算法复制一遍，而是从几何事实约束结果。

本项目保留九项数值与 Blender 集成测试，并在末尾验证一次 unregister、register、unregister 生命周期。这些测试已在 Windows Blender 4.5.1 LTS 中通过。它们没有覆盖所有材质、相机和场景组合，不能把“九项通过”扩写成“兼容所有 Blender 文件”。

| 测试 | 要防止的错误 |
| --- | --- |
| 最近表面在两种提交顺序下获胜 | 用画家顺序误代替深度测试 |
| near plane 裁剪保留可见部分 | 整面误删、交点属性错误 |
| 相机后方三角形被拒绝 | 负 w 投影到画面前方 |
| 透视插值使用 reciprocal w | 倾斜表面的属性扭曲 |
| 阴影遮挡与无遮挡接收点 | 光空间方向或深度比较反转 |
| 空场景与颜色往返 | 背景失效、编码边界错误 |
| 取消渲染 | 耗时工作不响应取消 |
| 求值修改器与隐藏对象 | 读到原始网格或错误可见性 |
| 集合实例拥有独立变换 | 实例丢失或重叠在源位置 |

## 一个断言如何比截图更精确

深度测试构造两个屏幕覆盖相同、z 分别为 -0.5 和 0.5 的面，赋予不同颜色。无论提交顺序如何，指定内部像素都应为近面的红色，深度应为 -0.5。这直接排除了“颜色恰巧差不多所以没看出错误”。

:::code tests/verify_renderer.py#RasterTests.test_nearest_surface_wins_in_both_submission_orders

透视测试则固定一个像素的屏幕重心坐标，用手算的 w 校正作为期望。近裁剪测试既检查产生两个三角形，也检查每个新顶点满足裁剪半空间、属性随交点正确插值，以及画面里确实留下可见像素。

## 集成测试检查宿主语义

数值核心不知道什么是 Blender 修改器或集合实例。测试创建一个带两个阵列副本的立方体，再创建隐藏对象，断言导出的三角形数量和最大坐标。另一个测试把同一源集合放到两个位置，检查两个对象 id 和左右范围。

这些是容易被“我的演示渲染正常”遗漏的问题。静物脚本的原始对象路径可能一直工作，而用户第一次带入实例场景就失败。因此，测试输入应主动覆盖与演示不同的结构。

:::code tests/verify_renderer.py#BlenderTests.test_collection_instances_have_independent_transforms

## 打包测试必须在新进程里做

`verify_package.py` 把 ZIP 放到 Python 搜索路径首位，确认实际导入位置包含 .zip，注册引擎，重新打开保存的 .blend，检查引擎、相机、色阶和内嵌图像，再以 320×240 重新渲染。

:::figure output/checks/reopened_scene.png | 这张小图由新 Blender 进程从 ZIP 和保存的场景重新渲染，验证交付链路。

新进程很重要：当前进程中的 `sys.modules`、已注册类、内存中的图片和未保存数据，都可能掩盖包或场景里缺少的内容。

:::code tests/verify_package.py

参考图差异检查在图像中部裁剪区域计算 MAE，避开标题和页脚。实际报告值为 0.14714，大于检查阈值 0.025，支持“画面中的物体风格有明显差异”。它不是感知质量评分，也不能证明几何或阴影正确；对照图本来就采用不同光照模型。

## 复现命令与后续补充

在原生 Windows Git Bash、项目根目录执行：

```bash
"/c/Program Files/Blender Foundation/Blender 4.5/blender.exe" --background --factory-startup --python-exit-code 1 --python tests/verify_renderer.py
"/c/Program Files/Blender Foundation/Blender 4.5/blender.exe" --background --factory-startup --python-exit-code 1 --python tests/verify_package.py
```

包测试会重写 `output/checks` 的检查产物。建议在档案馆下载的项目副本中运行，以保持本书快照稳定。后续最值得补充的是非均匀缩放法线、公共边填充、像素宽高比、不同透视相机、取消延迟，以及配置被明确拒绝时的错误路径。

:::exercise 一张随机大场景图很漂亮，能替代这些小测试吗？
不能。它可以发现整体观感问题，却难以给出每个像素的已知答案。小测试定位算法事实，集成测试定位宿主交互，完整场景定位整体表现，三者承担不同责任。
:::
