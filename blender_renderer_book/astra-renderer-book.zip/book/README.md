# 本地交互书的文件与维护

入口是 [index.html](index.html)。全部正文、图像、交互实验和源码搜索可通过 `file://` 离线使用，无 CDN、网络字体、fetch 或 ES module 依赖。外部参考资料链接需要网络，.blend 场景需要 Blender。

| 文件 | 用途 |
| --- | --- |
| chapters/*.md | 27 章中文稿件、公式、练习、源码与实验插入标记 |
| toc.json | 章节顺序、书中部次、标题与副标题 |
| build_book.py | 标准库构建器：冻结项目快照、编译内容与搜索数据 |
| index.html / style.css | 阅读器外壳、排版、响应式与当前章打印 |
| reader.js | 导航、搜索、行号源码、复制、字号、主题和阅读记录 |
| labs.js | 11 个数学与图像交互实验 |
| data.js | 生成的章节与完整源码数据，可由普通 script 直接加载 |
| project/ | 15 个原项目文件的完整快照 |
| manifest.json | 项目快照大小和 SHA-256 |
| astra-press-project.zip | 单独下载并继续开发的原项目 |
| verification/ | 实际 Windows 浏览器检查报告与桌面、手机截图 |
| verify_book.cjs | 无 npm 依赖的原生浏览器验收脚本 |
| package_book.py | 便携 ZIP 生成与压缩包内容校验 |

## 构建

在原生 Windows Git Bash、项目根目录运行：

```bash
"/c/Program Files/Blender Foundation/Blender 4.5/blender.exe" --background --factory-startup --python-exit-code 1 --python book/build_book.py
```

构建器只用 Python 标准库，普通 Python 3 也能运行。第一次从项目根目录复制基线，之后保留已有 project 文件。如果要建立新版本，应显式管理新快照，而不是无意覆盖旧书的证据。`build-report.json` 记录章节、中文字符、源码行和实验数量。

仓库只跟踪书稿、阅读器和构建工具；`data.js`、`project/`、书籍 ZIP、清单及浏览器报告均为被忽略的构建产物。渲染器原始示例图片、场景和检查报告仍作为构建输入跟踪，克隆后运行构建命令即可阅读。`baseline/gitignore` 保存制书时的原始忽略规则，避免仓库新增规则改变书中历史快照；其余 14 个基线文件从项目根目录读取。`.gitattributes` 保留文件原始字节，避免 Windows Git 换行转换影响 SHA-256。

支持的轻量标记包括标题、列表、表格、代码块，以及：

```text
:::code astra_press/core.py#clip_triangle
:::code astra_press/__init__.py#AstraRenderEngine.render
:::lab clipping
:::figure output/astra_press.png | 图注
:::metrics
:::archive
:::exercise 问题
参考答案
:::
:::equation 图注
纯文本 Unicode 公式
:::
:::note 标题
提示文字
:::
```

源码节选用 AST 定位原始函数或类，直接从快照摘取，保留原行号。普通 Markdown 模块与复杂数学排版库均不是构建依赖。

## 验证

```bash
node book/verify_book.cjs
```

需要原生 Windows Node 22+（使用内置 WebSocket），以及已安装的 Edge 或 Chrome。可以通过 `ASTRA_BOOK_BROWSER` 指定浏览器可执行文件。脚本创建独立的临时浏览器配置目录，在结束后关闭该进程并删除目录，不使用读者的正常浏览器资料。

脚本检查全部章节、内链、文件哈希、源码逐行一致性、实验数值与操作、图片解码、中文与源码搜索、偏好持久化、390px 手机排版和打印样式。它打开真实本地文件并将页面网络设为离线，记录外部请求数和 JavaScript 异常数。报告中的通过状态与原生任务退出码一起判断。

## 打包

```bash
"/c/Program Files/Blender Foundation/Blender 4.5/blender.exe" --background --factory-startup --python-exit-code 1 --python book/package_book.py
```

在上级目录生成 `astra-renderer-book.zip`，带有一键打开入口和本书完整文件。打包器只收集明确列出的书籍文件，检查 ZIP CRC 与每个条目的字节一致性；不会打入编辑器缓存、浏览器配置目录或无关文件。

在 WSL 协作环境中，原生 Blender、Node 与浏览器应继续通过 delegate_runner 启动。本书的纯文件编辑可在 WSL 完成。

## 导出到现有 GitHub Pages

本书发布于 <https://uppet.github.io/blender_renderer_book/>。构建、浏览器检查与便携打包完成后，在项目根目录运行：

```bash
python book/export_pages.py .publish/pages/blender_renderer_book
```

目标必须不存在或为空。导出器按明确清单复制页面、附件和离线整本 ZIP，并记录 `publication-manifest.json`。它只生成文件，不执行 Git 或发布操作。源码里保留的是导出器，导出目录不纳入本项目 Git。

现有站点使用 Jekyll。导出器仅为 `.gitignore`、`README.md` 和 `__init__.py` 使用普通 `.txt` 下载地址，保留内容字节、源码显示名称及 ZIP 中的原始路径；下载按钮指定原始文件名。这样无需更改既有博客配置。在线页脚增加离线整本 ZIP 下载入口。

发布后可复用完整浏览器验收：

```bash
ASTRA_BOOK_URL=https://uppet.github.io/blender_renderer_book/ node book/verify_book.cjs
```

在线报告写入被忽略的 `.publish/online-checks/`，不覆盖离线打包依据。维护工程的仓库与发布步骤另外记录在私有源码仓库根目录的 `PUBLICATION.md`。
