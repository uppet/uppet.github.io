"""Build an offline, dependency-free book using the Blender-bundled Python.

Run: blender --background --factory-startup --python-exit-code 1 --python book/build_book.py
The first build freezes the renderer project. Later builds preserve that snapshot.
"""

import ast
import hashlib
import html
import json
from pathlib import Path
import re
import shutil
import zipfile

BOOK = Path(__file__).resolve().parent
ROOT = BOOK.parent
PROJECT = BOOK / 'project'
PROJECT_FILES = [
    '.gitignore', 'README.md', 'render_demo.py', 'astra_press/__init__.py', 'astra_press/core.py',
    'tests/verify_renderer.py', 'tests/verify_package.py', 'astra_press.zip',
    'output/astra_press.png', 'output/cycles_reference.png', 'output/quiet_objects.blend',
    'output/compare.html', 'output/astra_press_report.json',
    'output/checks/package_report.json', 'output/checks/reopened_scene.png',
]
TEXT_SUFFIXES = {'.py', '.md', '.json', '.html'}
FILES = {}


def escape(value):
    return html.escape(str(value), quote=True)


def inline(value):
    tokens = []

    def protect(match):
        tokens.append('<code>' + escape(match.group(1)) + '</code>')
        return f'\x00{len(tokens)-1}\x00'

    value = re.sub(r'`([^`]+)`', protect, value)
    value = escape(value)
    value = re.sub(r'\[([^\]]+)\]\(([^)]+)\)', lambda m: '<a href="' + m.group(2) + '"' + (' target="_blank" rel="noreferrer"' if m.group(2).startswith('https:') else '') + '>' + m.group(1) + '</a>', value)
    value = re.sub(r'\*\*(.+?)\*\*', r'<strong>\1</strong>', value)
    value = re.sub(r'\*([^*]+)\*', r'<em>\1</em>', value)
    for i, token in enumerate(tokens):
        value = value.replace(f'\x00{i}\x00', token)
    return value


def source_block(spec):
    path, _, symbol = spec.partition('#')
    data = FILES[path]
    start, end = 1, len(data['text'].splitlines())
    if symbol:
        node = ast.parse(data['text'])
        for name in symbol.split('.'):
            node = next(n for n in node.body if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)) and n.name == name)
        start = min([node.lineno] + [decorator.lineno for decorator in node.decorator_list])
        end = node.end_lineno
    code = '\n'.join(data['text'].splitlines()[start-1:end])
    return ('<figure class="code-card"><figcaption><span>' + escape(path) + ' · L' + str(start) + '–' + str(end) + '</span><a href="#source/' + escape(path) + ':' + str(start) + '">查看完整源码 ↗</a></figcaption><pre><code class="language-python">' + escape(code) + '</code></pre></figure>')


def markdown(text, chapter_id, toc=None):
    lines = text.strip().splitlines()
    out = []
    i = 0
    heading_index = 0
    while i < len(lines):
        line = lines[i].strip()
        if not line:
            i += 1
            continue
        if line.startswith('```'):
            language, code = line[3:], []
            i += 1
            while i < len(lines) and not lines[i].strip().startswith('```'):
                code.append(lines[i]); i += 1
            out.append('<div class="code-card"><div class="code-label">' + escape(language or 'text') + '</div><pre><code class="language-' + escape(language) + '">' + escape('\n'.join(code)) + '</code></pre></div>')
            i += 1
            continue
        if line.startswith(':::code '):
            out.append(source_block(line.split(' ', 1)[1])); i += 1; continue
        if line.startswith(':::lab '):
            lab = line.split(' ', 1)[1]
            out.append('<section class="lab" data-lab="' + escape(lab) + '"><p>交互实验正在准备。请启用浏览器 JavaScript。</p></section>')
            i += 1; continue
        if line == ':::metrics':
            out.append('<div class="metrics" data-metrics></div>'); i += 1; continue
        if line == ':::archive':
            out.append('<div data-archive></div>'); i += 1; continue
        if line.startswith(':::figure '):
            path, _, caption = line[10:].partition(' | ')
            out.append('<figure class="image-figure"><a href="project/' + escape(path) + '" target="_blank"><img loading="lazy" src="project/' + escape(path) + '" alt="' + escape(caption) + '"></a><figcaption>' + inline(caption) + '</figcaption></figure>')
            i += 1; continue
        if line.startswith(':::'):
            kind, _, title = line[3:].partition(' ')
            body = []
            i += 1
            while i < len(lines) and lines[i].strip() != ':::':
                body.append(lines[i]); i += 1
            rendered = markdown('\n'.join(body), chapter_id + '-aside')
            if kind == 'exercise':
                out.append('<details class="exercise"><summary><span>练习与参考答案</span>' + inline(title) + '</summary><div>' + rendered + '</div></details>')
            elif kind == 'equation':
                out.append('<figure class="equation"><pre>' + escape('\n'.join(body)) + '</pre><figcaption>' + inline(title) + '</figcaption></figure>')
            else:
                out.append('<aside class="callout ' + escape(kind) + '"><div class="callout-title">' + inline(title) + '</div>' + rendered + '</aside>')
            i += 1; continue
        match = re.match(r'^(#{2,3}) (.+)', line)
        if match:
            level = len(match[1]); heading_index += 1
            anchor = chapter_id + '-s' + str(heading_index)
            out.append(f'<h{level} id="{anchor}">' + inline(match[2]) + f'</h{level}>')
            if toc is not None:
                toc.append({'title': match[2], 'id': anchor, 'level': level})
            i += 1; continue
        if line.startswith('|') and i + 1 < len(lines) and re.match(r'^\|[\s:|-]+\|$', lines[i+1].strip()):
            headers = [v.strip() for v in line.strip('|').split('|')]
            rows = []; i += 2
            while i < len(lines) and lines[i].strip().startswith('|'):
                rows.append([v.strip() for v in lines[i].strip().strip('|').split('|')]); i += 1
            out.append('<div class="table-scroll"><table><thead><tr>' + ''.join('<th>' + inline(v) + '</th>' for v in headers) + '</tr></thead><tbody>' + ''.join('<tr>' + ''.join('<td>' + inline(v) + '</td>' for v in row) + '</tr>' for row in rows) + '</tbody></table></div>')
            continue
        if re.match(r'^(- |\d+\. )', line):
            ordered = bool(re.match(r'^\d+\.', line)); tag = 'ol' if ordered else 'ul'
            items = []
            pattern = r'^\d+\. (.*)' if ordered else r'^- (.*)'
            while i < len(lines):
                item = re.match(pattern, lines[i].strip())
                if not item: break
                items.append('<li>' + inline(item[1]) + '</li>'); i += 1
            out.append('<' + tag + '>' + ''.join(items) + '</' + tag + '>'); continue
        paragraph = [line]; i += 1
        while i < len(lines) and lines[i].strip() and not re.match(r'^(#{2,3} |:::|```|\||- |\d+\. )', lines[i].strip()):
            paragraph.append(lines[i].strip()); i += 1
        out.append('<p>' + inline(' '.join(paragraph)) + '</p>')
    return '\n'.join(out)


def main():
    PROJECT.mkdir(parents=True, exist_ok=True)
    for relative in PROJECT_FILES:
        # The repository ignore rules evolve independently of the book's baseline.
        source = BOOK / 'baseline/gitignore' if relative == '.gitignore' else ROOT / relative
        destination = PROJECT / relative
        if not destination.exists():
            destination.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(source, destination)
        raw = destination.read_bytes()
        text_file = destination.suffix in TEXT_SUFFIXES or destination.name == '.gitignore'
        FILES[relative] = {'path': relative, 'size': len(raw), 'sha256': hashlib.sha256(raw).hexdigest(),
                           'href': 'project/' + relative, 'kind': 'text' if text_file else 'asset'}
        if text_file:
            FILES[relative]['text'] = raw.decode('utf-8-sig').replace('\r\n', '\n')
    toc = json.loads((BOOK / 'toc.json').read_text(encoding='utf-8'))
    total_han = 0
    for index, chapter in enumerate(toc):
        path = BOOK / 'chapters' / (chapter['id'] + '.md')
        text = path.read_text(encoding='utf-8')
        chapter['number'] = f'{index:02d}'
        chapter['toc'] = []
        chapter['html'] = markdown(text, chapter['id'], chapter['toc'])
        chapter['plain'] = html.unescape(re.sub(r'<[^>]*>', ' ', chapter['html']))
        chapter['han'] = len(re.findall(r'[\u4e00-\u9fff]', text))
        total_han += chapter['han']
        chapter['minutes'] = max(3, round(chapter['han'] / 260 + chapter['html'].count('data-lab') * 3))
    reports = {name: json.loads((PROJECT / path).read_text(encoding='utf-8')) for name, path in (
        ('render', 'output/astra_press_report.json'), ('package', 'output/checks/package_report.json'))}
    manifest = {'snapshot': 'Astra Press 0.1.0 / Blender 4.5.1 LTS', 'created': '2026-09-07',
                'files': [{k: v for k, v in item.items() if k != 'text'} for item in FILES.values()]}
    (BOOK / 'manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding='utf-8')
    data = {'title': '自己写一个 Blender 渲染器', 'edition': 'Astra Press · 实作版 01',
            'chapters': toc, 'files': FILES, 'reports': reports, 'han': total_han,
            'snapshot': manifest['snapshot'], 'created': manifest['created']}
    (BOOK / 'data.js').write_text('window.BOOK = ' + json.dumps(data, ensure_ascii=False, separators=(',', ':')) + ';\n', encoding='utf-8')
    with zipfile.ZipFile(BOOK / 'astra-press-project.zip', 'w', zipfile.ZIP_DEFLATED) as archive:
        for relative in PROJECT_FILES:
            archive.write(PROJECT / relative, relative)
    report = {'chapters': len(toc), 'chinese_characters': total_han,
              'snapshot_files': len(FILES), 'source_lines': sum(len(f.get('text', '').splitlines()) for f in FILES.values()),
              'interactive_instances': sum(c['html'].count('data-lab=') for c in toc),
              'source_excerpts': sum(c['html'].count('查看完整源码') for c in toc)}
    (BOOK / 'build-report.json').write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
    print('BOOK_BUILD_OK ' + json.dumps(report), flush=True)


if __name__ == '__main__':
    main()
