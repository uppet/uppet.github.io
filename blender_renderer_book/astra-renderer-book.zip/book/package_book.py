"""Create and verify a portable offline book after browser acceptance passes."""
import hashlib
import json
from pathlib import Path
import zipfile

BOOK = Path(__file__).resolve().parent
ROOT = BOOK.parent


def main():
    browser_report = json.loads((BOOK / 'verification/browser-report.json').read_text(encoding='utf-8'))
    if not browser_report.get('passed') or browser_report.get('browserExitCode') != 0:
        raise RuntimeError('A successful native browser verification is required before packaging.')
    for name, expected in browser_report['verifiedFiles'].items():
        actual = hashlib.sha256((BOOK / name).read_bytes()).hexdigest()
        if actual != expected:
            raise RuntimeError(f'Book changed since browser verification: {name}')
    names = [
        'index.html', 'style.css', 'reader.js', 'labs.js', 'data.js', 'toc.json',
        'build_book.py', 'verify_book.cjs', 'package_book.py', 'export_pages.py', 'README.md',
        'baseline/gitignore',
        'manifest.json', 'build-report.json', 'astra-press-project.zip',
        'verification/browser-report.json',
    ]
    files = [BOOK / name for name in names]
    files.extend(sorted((BOOK / 'chapters').glob('*.md')))
    files.extend(sorted(path for path in (BOOK / 'project').rglob('*') if path.is_file()))
    files.extend(BOOK / 'verification' / name for name in browser_report['screenshots'])
    files.extend((ROOT / '打开这本书.html', ROOT / 'READ_THE_BOOK.md'))
    if any(not path.is_file() for path in files):
        raise RuntimeError('A required book file is missing.')
    archive_path = ROOT / 'astra-renderer-book.zip'
    with zipfile.ZipFile(archive_path, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for path in files:
            archive.write(path, path.relative_to(ROOT).as_posix())
    with zipfile.ZipFile(archive_path) as archive:
        if archive.testzip() is not None:
            raise RuntimeError('Portable archive CRC verification failed.')
        for path in files:
            if archive.read(path.relative_to(ROOT).as_posix()) != path.read_bytes():
                raise RuntimeError(f'Portable archive content mismatch: {path}')
        entries = archive.namelist()
    raw = archive_path.read_bytes()
    report = {
        'file': archive_path.name, 'bytes': len(raw),
        'sha256': hashlib.sha256(raw).hexdigest(),
        'entries': len(entries), 'crc_verified': True, 'all_entry_bytes_verified': True,
        'entrypoint': '打开这本书.html', 'book_entrypoint': 'book/index.html',
        'browser_verified': browser_report['version']['product'],
    }
    (BOOK / 'portable-report.json').write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
    print('BOOK_PACKAGE_OK ' + json.dumps(report, ensure_ascii=False), flush=True)


if __name__ == '__main__':
    main()
