# 自己写一个 Blender 渲染器

在线阅读：<https://uppet.github.io/blender_renderer_book/>。网页底部可下载离线整本 ZIP。

从源码仓库克隆后，先在根目录执行 `python book/build_book.py` 生成被 Git 忽略的书本构建产物，再按下面的方法本地阅读。下载的离线整本 ZIP 已含构建结果，解压即可阅读。

双击本目录的 **打开这本书.html**，或用浏览器打开 **book/index.html**。

在原项目中的完整 Windows 路径是：

```text
D:\bld\astra_render\打开这本书.html
```

无需启动服务器、安装网页依赖或联网。建议使用现代 Edge、Chrome 或 Firefox；本版已经在原生 Windows Edge 中完成实际浏览器验证。阅读不需要 Blender，重新运行渲染器才需要。

全书 27 章，约 2.9 万汉字，包含 11 个交互实验、22 处与实际源码对应的节选、完整源码浏览器、折叠练习与答案，以及原项目的全部 15 个文件快照。覆盖 Blender 接入、场景求值、矩阵与相机、裁剪、插值、阴影、颜色、版画风格、测试、交付，以及 C++/GPU、射线和路径追踪的扩展设计。

使用 Ctrl+K 搜索正文与源代码；右上角调整字号、切换深色模式或打印当前章节；章末可标记已读。读者的设置保存在当前浏览器本地。

**搬到另一台电脑：** 解压 `astra-renderer-book.zip` 的全部内容，再双击其中的“打开这本书.html”。不要只复制 index.html，它需要同目录内的脚本、样式与图片。

**继续开发渲染器：** 在书内“源码与产物档案馆”下载 `astra-press-project.zip`，解压到新的工作目录。书中的 `book/project/` 保留原始快照，便于对应章节、行号、图片与报告。

**维护本书：** 构建与验证说明在 [book/README.md](book/README.md)。浏览器检查结果保存在 [browser-report.json](book/verification/browser-report.json)。
